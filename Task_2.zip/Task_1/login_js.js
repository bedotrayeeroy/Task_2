$(document).ready(function(){
   $("#login").click(function(){
    window.location.href="dasbrd.html";  
  });
 

}); 
     /*var email=$("#email").val();;
     var password=$("#password").val();;
  var listofobj=[];
       $.ajax({
     url:"https://reqres.in/api/users",
     method:"GET",
    key:{
       email:email,
       password:password
     },
       }).done(function(data){ 
 
        for(var i=0; i<data.data.length;i++){
          var person={
            id:data.data[i].id,
            email:data.data[i].email,
            first_name:data.data[i].first_name,
            last_name:data.data[i].last_name,
          };
            listofobj.push(person);
        }   
         localStorage.setItem('list',JSON.stringify(listofobj)); */
       

     
    

 
  